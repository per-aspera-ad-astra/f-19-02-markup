$(function() {
  jcf.replaceAll();
});

