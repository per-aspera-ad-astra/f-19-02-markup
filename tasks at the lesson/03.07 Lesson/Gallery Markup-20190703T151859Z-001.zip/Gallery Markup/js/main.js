$(document).ready(function() {

  $('.slider').slick({
    dots: true,
    // slidesToShow: 1,
    // slidesToScroll: 1,
    speed: 400,
    autoplay: true,
    autoplaySpeed: 1000,
    fade: true,
    cssEase: 'linear',
    // infinite: false,
    // arrows: false,



  });



  
});

